import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function MadiirInsightsWebsite() {
  return (
    <div className="font-sans text-gray-800 bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow p-4 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <img src="/logo.png" alt="Madiir Logo" className="h-10 w-auto" />
          <h1 className="text-2xl font-bold text-blue-900">Madiir Insights</h1>
        </div>
        <nav className="space-x-4 text-black font-medium">
          <a href="#about" className="hover:text-blue-700">About</a>
          <a href="#services" className="hover:text-blue-700">Services</a>
          <a href="#industries" className="hover:text-blue-700">Industries</a>
          <a href="#contact" className="hover:text-blue-700">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-black p-12 text-center text-white">
        <h2 className="text-5xl font-bold mb-4">Clarity in Every Move</h2>
        <p className="text-xl mb-6">Empowering smarter decisions through insight-driven strategy and data intelligence.</p>
        <Button className="bg-white text-blue-900 hover:bg-blue-200">Get in Touch</Button>
      </section>

      {/* About Section */}
      <section id="about" className="p-8 bg-white">
        <h3 className="text-3xl font-semibold mb-4 text-blue-900">About Madiir Insights</h3>
        <p className="mb-4">Madiir Insights is a strategic advisory and business intelligence firm based in Juba, South Sudan. We help organizations turn complexity into clarity using data, research, and foresight-driven strategies.</p>
        <p>Founded in 2025, our mission is to support confident, informed decisions for sustainable growth across sectors.</p>
      </section>

      {/* Services Section */}
      <section id="services" className="p-8 bg-gray-100">
        <h3 className="text-3xl font-semibold mb-4 text-blue-900">Our Services</h3>
        <ul className="list-disc list-inside space-y-2 text-lg">
          <li>Business Intelligence & Analytics</li>
          <li>Strategic Advisory</li>
          <li>Customer & Community Insights</li>
          <li>Foresight & Scenario Planning</li>
          <li>Organizational Capacity Building</li>
        </ul>
      </section>

      {/* Industries Section */}
      <section id="industries" className="p-8 bg-white">
        <h3 className="text-3xl font-semibold mb-4 text-blue-900">Industries We Serve</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card><CardContent className="p-4">Government & Public Sector</CardContent></Card>
          <Card><CardContent className="p-4">NGOs & Development Partners</CardContent></Card>
          <Card><CardContent className="p-4">Finance & Microfinance</CardContent></Card>
          <Card><CardContent className="p-4">Health & Education</CardContent></Card>
          <Card><CardContent className="p-4">Agriculture & Infrastructure</CardContent></Card>
          <Card><CardContent className="p-4">Technology & Startups</CardContent></Card>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="p-8 bg-gray-100">
        <h3 className="text-3xl font-semibold mb-4 text-blue-900">Contact Us</h3>
        <p className="mb-2">📍 Juba, South Sudan</p>
        <p className="mb-2">📞 +211 927 633 080 | +211 988 606 052</p>
        <p className="mb-4">📧 madiirinsights@gmail.com</p>
        <div className="max-w-md">
          <Input placeholder="Your Name" className="mb-2" />
          <Input placeholder="Your Email" className="mb-2" />
          <Input placeholder="Your Message" className="mb-2" />
          <Button className="bg-blue-900 text-white hover:bg-blue-700">Send Message</Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white text-center p-4 text-sm text-gray-600">
        &copy; 2025 Madiir Insights. All rights reserved.
      </footer>
    </div>
  );
}
